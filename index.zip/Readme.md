# PUBLICITYASIA

The Philippines' Leading PR Agency. Public Relations Firm. Celebrity. Entertainment. Sports. Business. Lifestyle. Travel. Tech. Digital. Social Media. Events.

# Clear the Cache

Clear the cache and config, then deploy to the live server.

If you've already uploaded to the live server, then you have to follow these steps:

1. Delete bootstrap/cache/config.php
2. Delete all log files in storage/logs.